//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ShellExt.rc
//
#define IDS_PROJNAME                    100
#define IDS_TYPE                        101
#define IDC_ABOUT                       201
#define IDC_LIST                        202
#define IDC_FSCK                        203
#define IDC_STATIC_CR                   203
#define IDD_WIN2FS_DRIVEPAGE            203
#define IDC_STATIC_URL                  203
#define IDD_ABOUTDLG                    204
#define IDC_FORMAT                      204
#define IDI_ICON                        205
#define IDC_CHECK_UREAD                 206
#define IDB_LOGO                        207
#define IDC_CHECK_UWRITE                207
#define IDC_CHECK_UEXEC                 208
#define IDC_CHECK_SUID                  209
#define IDC_CHECK_GREAD                 210
#define IDC_STATIC_VERSION_EX           210
#define IDD_WIN2FS_FOLDERPAGE           211
#define IDC_CHECK_GWRITE                211
#define IDC_STATIC_COPYRIGHT            211
#define IDD_WIN2FS_FILEPAGE             212
#define IDC_CHECK_GEXEC                 212
#define IDC_CHECK_SGID                  213
#define IDC_CHECK_OREAD                 214
#define IDC_CHECK_OWRITE                215
#define IDC_CHECK_OEXEC                 216

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        213
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         212
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
