
 CPL - Control Panel Applets
 ---------------------------

    o  This is the project for generating the control panel applet 
       used by Win2fs.

    o  Control panel extensions are Win32 dlls with a specific set of
       entry points and a .CPL extension.

    o  A single .CPL file can contain any number of applets inside it.
    
    o  The framework for developing a .CPL file is documented in the MSDN.

    o  Thanks to Len from JetByte Ltd. for getting us started.  

        
