//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MainApp.rc
//
#define IDD_DRVSELDLG                   101
#define IDD_MAINDLG                     102
#define IDI_DLGFRAME                    111
#define IDD_INFODLG                     124
#define IDD_ABOUTDLG                    126
#define IDS_ABOUTBOX                    128
#define IDC_STATIC_URL                  203
#define IDB_LOGO                        207
#define IDC_COMBO_DRIVE                 1000
#define IDC_BUTTON_MOUNT                1001
#define IDC_BUTTON_REFRESH              1002
#define IDC_BUTTON_INFO                 1003
#define IDC_BUTTON_CLOSE                1006
#define IDC_BUTTON_ABOUT                1007
#define IDC_LIST_PART                   1902
#define IDC_LIST                        2115
#define IDC_CHECK_PERSIST               2116
#define IDC_STATIC_VERSION_EX           2117
#define IDC_STATIC_COPYRIGHT            2118

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        127
#define _APS_NEXT_COMMAND_VALUE         40013
#define _APS_NEXT_CONTROL_VALUE         2119
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
